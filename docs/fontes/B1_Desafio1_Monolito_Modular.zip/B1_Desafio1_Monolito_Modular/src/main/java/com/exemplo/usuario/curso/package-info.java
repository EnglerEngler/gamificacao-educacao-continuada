/** Módulo de negócio: Catálogo de cursos. A organização é vertical por capacidade. */
package com.exemplo.usuario.curso;
