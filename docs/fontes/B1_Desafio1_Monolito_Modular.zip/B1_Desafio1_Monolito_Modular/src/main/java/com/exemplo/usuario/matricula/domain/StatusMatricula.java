package com.exemplo.usuario.matricula.domain;

// Enum do dominio para os estados da matricula.
public enum StatusMatricula {
    EM_ANDAMENTO,
    CONCLUIDO,
    CANCELADO
}
