/** Módulo de negócio: Matrículas e conclusão. A organização é vertical por capacidade. */
package com.exemplo.usuario.matricula;
