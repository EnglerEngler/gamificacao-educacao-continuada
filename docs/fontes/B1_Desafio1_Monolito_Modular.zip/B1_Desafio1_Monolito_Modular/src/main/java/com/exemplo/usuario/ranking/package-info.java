/** Módulo de negócio: Leitura de ranking. A organização é vertical por capacidade. */
package com.exemplo.usuario.ranking;
