package com.exemplo.usuario.usuario.domain;

// Enum do dominio.
// Representa os possiveis planos de assinatura.
public enum PlanoAssinatura {
    BASICO,
    PREMIUM
}
