/** Módulo de negócio: Usuários e assinatura. A organização é vertical por capacidade. */
package com.exemplo.usuario.usuario;
